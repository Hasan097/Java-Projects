/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heptalion;

/**
 *
 * @author villa
 */
public class NameTooShort extends Exception {

    
//    public NameTooShort(String name) throws NameTooShort {
//        if(name.length() < Player.MIN_NAME_LENGTH)
//            throw new NameTooShort();
//    }
//
//    private NameTooShort() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
}
